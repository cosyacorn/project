void send_boundary_data(Field* f_b, Array* a);
