void parallel_swap_alg(int num_nodes, int num_swaps, Array *a, Array *b);
void reverse_engineer(int ** in, int ** out, int num_nodes);
