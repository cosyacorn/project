void send_boundary_data(Field* f, Array* a);
